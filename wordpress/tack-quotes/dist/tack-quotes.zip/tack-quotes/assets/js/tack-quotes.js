/* global TackQuotes, jQuery */
( function ( $ ) {
	'use strict';

	function promptEmail() {
		// Prefer a logged-in email if WooCommerce exposed one; otherwise ask.
		return window.prompt( 'Enter your email to receive the quote:' ) || '';
	}

	$( document ).on( 'click', '.tack-quote-btn', function ( e ) {
		e.preventDefault();
		var $btn = $( this );
		if ( $btn.data( 'loading' ) ) {
			return;
		}

		var email = promptEmail();
		if ( ! email ) {
			return;
		}

		var payload = {
			action: 'tack_request_quote',
			nonce: TackQuotes.nonce,
			email: email,
			from_cart: $btn.data( 'from-cart' ) ? 1 : 0,
			product_id: $btn.data( 'product-id' ) || 0,
			quantity: $( 'input.qty' ).val() || 1
		};

		var original = $btn.text();
		$btn.data( 'loading', true ).prop( 'disabled', true ).text( TackQuotes.i18n.sending );

		$.post( TackQuotes.ajaxUrl, payload )
			.done( function ( res ) {
				if ( res && res.success && res.data && res.data.portalUrl ) {
					window.location.href = res.data.portalUrl;
				} else {
					window.alert( ( res && res.data && res.data.message ) || TackQuotes.i18n.error );
				}
			} )
			.fail( function ( xhr ) {
				var msg = TackQuotes.i18n.error;
				if ( xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message ) {
					msg = xhr.responseJSON.data.message;
				}
				window.alert( msg );
			} )
			.always( function () {
				$btn.data( 'loading', false ).prop( 'disabled', false ).text( original );
			} );
	} );
}( jQuery ) );
