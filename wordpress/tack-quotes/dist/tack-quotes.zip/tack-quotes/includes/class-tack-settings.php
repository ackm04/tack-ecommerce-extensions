<?php
/**
 * Settings page (WordPress Settings API) — Tack API key, API URL, and toggles.
 *
 * @package TackQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the admin settings screen and options.
 */
class Tack_Settings {

	const OPTION_GROUP = 'tack_quotes_settings';
	const PAGE_SLUG    = 'tack-quotes';

	/**
	 * Hook registration.
	 */
	public function init() {
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Add the top-level admin menu page.
	 */
	public function add_menu() {
		add_menu_page(
			__( 'Tack Quotes', 'tack-quotes' ),
			__( 'Tack Quotes', 'tack-quotes' ),
			'manage_woocommerce',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			'dashicons-money-alt',
			56
		);
	}

	/**
	 * Register settings + fields with sanitization callbacks.
	 */
	public function register_settings() {
		register_setting( self::OPTION_GROUP, 'tack_quotes_api_key', array( 'sanitize_callback' => array( $this, 'sanitize_api_key' ) ) );
		register_setting( self::OPTION_GROUP, 'tack_quotes_api_url', array( 'sanitize_callback' => array( $this, 'sanitize_url' ) ) );
		register_setting( self::OPTION_GROUP, 'tack_quotes_button_label', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( self::OPTION_GROUP, 'tack_quotes_enable_widget', array( 'sanitize_callback' => array( $this, 'sanitize_checkbox' ) ) );
		register_setting( self::OPTION_GROUP, 'tack_quotes_enable_order_sync', array( 'sanitize_callback' => array( $this, 'sanitize_checkbox' ) ) );

		add_settings_section( 'tack_quotes_main', __( 'Connection', 'tack-quotes' ), array( $this, 'section_intro' ), self::PAGE_SLUG );

		add_settings_field( 'tack_quotes_api_key', __( 'Tack API Key', 'tack-quotes' ), array( $this, 'field_api_key' ), self::PAGE_SLUG, 'tack_quotes_main' );
		add_settings_field( 'tack_quotes_api_url', __( 'Tack API URL', 'tack-quotes' ), array( $this, 'field_api_url' ), self::PAGE_SLUG, 'tack_quotes_main' );
		add_settings_field( 'tack_quotes_button_label', __( 'Quote Button Label', 'tack-quotes' ), array( $this, 'field_button_label' ), self::PAGE_SLUG, 'tack_quotes_main' );
		add_settings_field( 'tack_quotes_enable_widget', __( 'Show Quote Button', 'tack-quotes' ), array( $this, 'field_enable_widget' ), self::PAGE_SLUG, 'tack_quotes_main' );
		add_settings_field( 'tack_quotes_enable_order_sync', __( 'Sync Orders to Tack', 'tack-quotes' ), array( $this, 'field_enable_order_sync' ), self::PAGE_SLUG, 'tack_quotes_main' );
	}

	// ── Sanitizers ────────────────────────────────────────────────────────────

	public function sanitize_api_key( $value ) {
		return preg_replace( '/[^A-Za-z0-9._\-]/', '', (string) $value );
	}

	public function sanitize_url( $value ) {
		return esc_url_raw( rtrim( (string) $value, '/' ) );
	}

	public function sanitize_checkbox( $value ) {
		return ( 'yes' === $value || '1' === $value || 'on' === $value ) ? 'yes' : 'no';
	}

	// ── Field renderers (escape all output) ─────────────────────────────────────

	public function section_intro() {
		echo '<p>' . esc_html__( 'Connect this store to your Tack account. Find your API key in Tack under Settings → Developer → API Keys.', 'tack-quotes' ) . '</p>';
	}

	public function field_api_key() {
		$value = (string) get_option( 'tack_quotes_api_key', '' );
		$masked = $value ? str_repeat( '•', 8 ) . substr( $value, -4 ) : '';
		printf(
			'<input type="password" name="tack_quotes_api_key" value="%s" class="regular-text" autocomplete="off" placeholder="%s" />',
			esc_attr( $value ),
			esc_attr__( 'Paste your Tack API key', 'tack-quotes' )
		);
		if ( $masked ) {
			echo '<p class="description">' . esc_html__( 'Saved key:', 'tack-quotes' ) . ' <code>' . esc_html( $masked ) . '</code></p>';
		}
	}

	public function field_api_url() {
		printf(
			'<input type="url" name="tack_quotes_api_url" value="%s" class="regular-text" placeholder="https://api.tackquote.com/v1" />',
			esc_attr( (string) get_option( 'tack_quotes_api_url', 'https://api.tackquote.com/v1' ) )
		);
	}

	public function field_button_label() {
		printf(
			'<input type="text" name="tack_quotes_button_label" value="%s" class="regular-text" />',
			esc_attr( (string) get_option( 'tack_quotes_button_label', __( 'Request a Quote', 'tack-quotes' ) ) )
		);
	}

	public function field_enable_widget() {
		$this->checkbox( 'tack_quotes_enable_widget', __( 'Display a "Request a Quote" button on products and the cart.', 'tack-quotes' ) );
	}

	public function field_enable_order_sync() {
		$this->checkbox( 'tack_quotes_enable_order_sync', __( 'Send new and updated WooCommerce orders to Tack.', 'tack-quotes' ) );
	}

	private function checkbox( $option, $label ) {
		$checked = ( 'yes' === get_option( $option, 'yes' ) );
		printf(
			'<label><input type="checkbox" name="%s" value="yes" %s /> %s</label>',
			esc_attr( $option ),
			checked( $checked, true, false ),
			esc_html( $label )
		);
	}

	// ── Page ────────────────────────────────────────────────────────────────────

	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'tack-quotes' ) );
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Tack Quotes', 'tack-quotes' ); ?></h1>
			<?php $this->maybe_show_test_result(); ?>
			<form method="post" action="options.php">
				<?php
				settings_fields( self::OPTION_GROUP );
				do_settings_sections( self::PAGE_SLUG );
				submit_button();
				?>
			</form>
			<hr />
			<h2><?php esc_html_e( 'Test connection', 'tack-quotes' ); ?></h2>
			<form method="post">
				<?php wp_nonce_field( 'tack_quotes_test', 'tack_quotes_test_nonce' ); ?>
				<input type="hidden" name="tack_quotes_action" value="test_connection" />
				<?php submit_button( __( 'Test Tack connection', 'tack-quotes' ), 'secondary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Handle the "Test connection" POST (nonce + capability enforced).
	 */
	private function maybe_show_test_result() {
		if ( ! isset( $_POST['tack_quotes_action'] ) || 'test_connection' !== $_POST['tack_quotes_action'] ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' )
			|| ! isset( $_POST['tack_quotes_test_nonce'] )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tack_quotes_test_nonce'] ) ), 'tack_quotes_test' ) ) {
			return;
		}
		$client = new Tack_Api_Client();
		$result = $client->test_connection();
		if ( is_wp_error( $result ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
		} else {
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Connected to Tack successfully.', 'tack-quotes' ) . '</p></div>';
		}
	}
}
