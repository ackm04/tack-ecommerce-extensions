<?php
/**
 * Frontend "Request a Quote" button on products and the cart, plus its AJAX handler.
 *
 * @package TackQuotes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the quote button and handles quote-request submissions.
 */
class Tack_Widget {

	/**
	 * Hook registration.
	 */
	public function init() {
		add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'render_product_button' ) );
		add_action( 'woocommerce_after_cart_totals', array( $this, 'render_cart_button' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		// AJAX (logged-in and guest).
		add_action( 'wp_ajax_tack_request_quote', array( $this, 'handle_request' ) );
		add_action( 'wp_ajax_nopriv_tack_request_quote', array( $this, 'handle_request' ) );
	}

	/**
	 * Enqueue the small JS/CSS the button needs.
	 */
	public function enqueue_assets() {
		if ( ! is_product() && ! is_cart() ) {
			return;
		}
		wp_enqueue_style( 'tack-quotes', TACK_QUOTES_URL . 'assets/css/tack-quotes.css', array(), TACK_QUOTES_VERSION );
		wp_enqueue_script( 'tack-quotes', TACK_QUOTES_URL . 'assets/js/tack-quotes.js', array( 'jquery' ), TACK_QUOTES_VERSION, true );
		wp_localize_script(
			'tack-quotes',
			'TackQuotes',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'tack_request_quote' ),
				'i18n'    => array(
					'sending' => __( 'Sending…', 'tack-quotes' ),
					'error'   => __( 'Could not create the quote. Please try again.', 'tack-quotes' ),
				),
			)
		);
	}

	/**
	 * Button under the single-product add-to-cart form.
	 */
	public function render_product_button() {
		global $product;
		if ( ! $product instanceof WC_Product ) {
			return;
		}
		$this->button( array( 'product_id' => $product->get_id() ) );
	}

	/**
	 * Button under the cart totals (quotes the whole cart).
	 */
	public function render_cart_button() {
		$this->button( array( 'from_cart' => 1 ) );
	}

	/**
	 * Output the button markup with data attributes.
	 *
	 * @param array $data Data attributes.
	 */
	private function button( $data ) {
		$label = (string) get_option( 'tack_quotes_button_label', __( 'Request a Quote', 'tack-quotes' ) );
		$attrs = '';
		foreach ( $data as $k => $v ) {
			$attrs .= sprintf( ' data-%s="%s"', esc_attr( $k ), esc_attr( $v ) );
		}
		printf(
			'<button type="button" class="button tack-quote-btn"%s>%s</button>',
			$attrs, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr above.
			esc_html( $label )
		);
	}

	/**
	 * AJAX handler: build line items from the product/cart and call the Tack API.
	 */
	public function handle_request() {
		check_ajax_referer( 'tack_request_quote', 'nonce' );

		$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$note       = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';
		$from_cart  = isset( $_POST['from_cart'] ) && '1' === sanitize_text_field( wp_unslash( $_POST['from_cart'] ) );
		$product_id = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		$quantity   = isset( $_POST['quantity'] ) ? max( 1, absint( wp_unslash( $_POST['quantity'] ) ) ) : 1;

		if ( '' === $email || ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'A valid email address is required.', 'tack-quotes' ) ), 400 );
		}

		$line_items = $from_cart ? $this->cart_line_items() : $this->product_line_items( $product_id, $quantity );
		if ( empty( $line_items ) ) {
			wp_send_json_error( array( 'message' => __( 'No products to quote.', 'tack-quotes' ) ), 400 );
		}

		$client = new Tack_Api_Client();
		$result = $client->create_quote_request(
			array(
				'buyerEmail' => $email,
				'note'       => $note,
				'source'     => 'woocommerce',
				'lineItems'  => $line_items,
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 502 );
		}

		wp_send_json_success(
			array(
				'quoteId'  => isset( $result['id'] ) ? $result['id'] : null,
				'portalUrl' => isset( $result['portalUrl'] ) ? esc_url_raw( $result['portalUrl'] ) : ( isset( $result['quoteUrl'] ) ? esc_url_raw( $result['quoteUrl'] ) : '' ),
			)
		);
	}

	/**
	 * Build a single-product line item.
	 *
	 * @param int $product_id Product ID.
	 * @param int $quantity   Quantity.
	 * @return array
	 */
	private function product_line_items( $product_id, $quantity ) {
		$product = $product_id ? wc_get_product( $product_id ) : null;
		if ( ! $product instanceof WC_Product ) {
			return array();
		}
		return array(
			array(
				'sku'                => $product->get_sku(),
				'name'               => $product->get_name(),
				'quantity'           => $quantity,
				'unitPrice'          => (float) wc_get_price_excluding_tax( $product ),
				'externalProductId'  => (string) $product->get_id(),
			),
		);
	}

	/**
	 * Build line items from the current cart.
	 *
	 * @return array
	 */
	private function cart_line_items() {
		if ( ! WC()->cart || WC()->cart->is_empty() ) {
			return array();
		}
		$items = array();
		foreach ( WC()->cart->get_cart() as $cart_item ) {
			/** @var WC_Product $product */
			$product = $cart_item['data'];
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			$items[] = array(
				'sku'               => $product->get_sku(),
				'name'              => $product->get_name(),
				'quantity'          => (int) $cart_item['quantity'],
				'unitPrice'         => (float) wc_get_price_excluding_tax( $product ),
				'externalProductId' => (string) $product->get_id(),
			);
		}
		return $items;
	}
}
