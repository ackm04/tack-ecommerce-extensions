=== Tack Quotes for WooCommerce ===
Contributors: tackquote
Tags: woocommerce, quotes, b2b, request a quote, wholesale
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add a "Request a Quote" button to WooCommerce and sync orders with your Tack B2B quoting account.

== Description ==

Tack Quotes connects your WooCommerce store to your Tack account:

* Adds a "Request a Quote" button on product pages and the cart.
* Sends new and updated orders to Tack automatically.
* Configure with a single API key.

This plugin is distributed via GitHub and is not hosted on the WordPress.org plugin directory.

== Installation ==

1. Upload the ZIP via Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Open "Tack Quotes" in the admin menu and paste your Tack API key.

== Frequently Asked Questions ==

= Where do I get an API key? =
In Tack, go to Settings → Developer → API Keys.

= Does it work with High-Performance Order Storage (HPOS)? =
Yes. The plugin declares HPOS compatibility.

== Changelog ==

= 1.0.0 =
* Initial release: quote button + order sync + settings.
